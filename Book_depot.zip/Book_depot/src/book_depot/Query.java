/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package book_depot;

/**
 *
 * @author goyal_puneet
 */
public class Query {

    void bookinsert(String Store_name, String bn_no, String book_name, String auther, String publisher, String mrp, String discount, String selling, String quantity, String version, String alert) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void bookupdate(String Store_name, String bn_no, String book_name, String auther, String publisher, String mrp, String discount, String selling, String quantity, String version, String alert) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void bookdelete(String bn_no) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void disdelete(String mob) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void disupdate(String distributer, String mob, String email, String add, String account, String ifc, String bname) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    void disinsert(String distributer, String mob, String email, String add, String account, String ifc, String bname) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}
