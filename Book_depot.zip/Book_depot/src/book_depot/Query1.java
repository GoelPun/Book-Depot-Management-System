package book_depot;

import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class Query1 {
	Connect co=new Connect();
	 String a,b,c;
	    public void dbInsert(String s1,String s2,String s3,String s4)
	    {
	        try
	       {
	        	PreparedStatement ps=null;
	        	
	           
	         ps=co.con.prepareStatement("insert into detail values('"+s1+"','"+s2+"','"+s3+"','"+s4+"')");
	         ps.executeUpdate();
	       }
	       catch(Exception e)
	       {
	           System.out.println(e);
	       }
	    }
	    
	    
	    
	    void dbselect(String s1)
	    {
	        try
	        {
	     	   PreparedStatement ps=null;
	     	   ResultSet rs=null;
	     	  
	     	  
	     	  // String a=null,b=null,c=null;
	            String val="select * from detail where name ='"+s1+"' ";
	          ps=co.con.prepareStatement(val);
	          rs=ps.executeQuery();
	          //System.out.println("Name\tID\tcontact");
	         // System.out.println();
	     

	          while(rs.next())
	          {
	         	   
	              a=rs.getString("Password");
	               
	          }
	       
	          
	        }
	        catch(Exception e)
	        {
	            System.out.println("goyal"+e.getMessage());
	        }
	    }
	    
}
